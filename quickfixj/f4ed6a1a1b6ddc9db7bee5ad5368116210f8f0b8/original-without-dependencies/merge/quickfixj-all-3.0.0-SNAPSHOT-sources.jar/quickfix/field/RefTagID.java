/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class RefTagID extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 371;

  public RefTagID() {
    super(371);
  }

  public RefTagID(Integer data) {
    super(371, data);
  }

  public RefTagID(int data) {
    super(371, data);
  }
}
