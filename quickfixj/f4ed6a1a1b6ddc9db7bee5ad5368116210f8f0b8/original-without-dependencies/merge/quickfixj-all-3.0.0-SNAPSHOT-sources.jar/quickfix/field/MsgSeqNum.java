/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class MsgSeqNum extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 34;

  public MsgSeqNum() {
    super(34);
  }

  public MsgSeqNum(Integer data) {
    super(34, data);
  }

  public MsgSeqNum(int data) {
    super(34, data);
  }
}
