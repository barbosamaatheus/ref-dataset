/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class EndSeqNo extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 16;

  public EndSeqNo() {
    super(16);
  }

  public EndSeqNo(Integer data) {
    super(16, data);
  }

  public EndSeqNo(int data) {
    super(16, data);
  }
}
