/* Generated Java Source File */
package quickfix.field;
import quickfix.BooleanField;

public class PossResend extends BooleanField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 97;

  public static final boolean ORIGINAL_TRANSMISSION = false;

  public static final boolean POSSIBLE_RESEND = true;

  public PossResend() {
    super(97);
  }

  public PossResend(Boolean data) {
    super(97, data);
  }

  public PossResend(boolean data) {
    super(97, data);
  }
}
