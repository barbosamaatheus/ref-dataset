/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class SecureData extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 91;

  public SecureData() {
    super(91);
  }

  public SecureData(String data) {
    super(91, data);
  }
}
