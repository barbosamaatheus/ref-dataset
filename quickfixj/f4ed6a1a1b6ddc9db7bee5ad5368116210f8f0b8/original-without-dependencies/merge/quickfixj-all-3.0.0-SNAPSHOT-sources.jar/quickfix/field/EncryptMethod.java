/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class EncryptMethod extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 98;

  public static final int NONE_OTHER = 0;

  public static final int PKCS = 1;

  public static final int DES = 2;

  public static final int PKCSDES = 3;

  public static final int PGPDES = 4;

  public static final int PGPDESMD5 = 5;

  public static final int PEM = 6;

  public EncryptMethod() {
    super(98);
  }

  public EncryptMethod(Integer data) {
    super(98, data);
  }

  public EncryptMethod(int data) {
    super(98, data);
  }
}
