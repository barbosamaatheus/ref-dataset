/* Generated Java Source File */
package quickfix.field;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import quickfix.UtcTimeStampField;

public class OrigSendingTime extends UtcTimeStampField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 122;

  public OrigSendingTime() {
    super(122);
  }

  public OrigSendingTime(LocalDateTime data) {
    super(122, data);
  }
}
