/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class TargetSubID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 57;

  public TargetSubID() {
    super(57);
  }

  public TargetSubID(String data) {
    super(57, data);
  }
}
