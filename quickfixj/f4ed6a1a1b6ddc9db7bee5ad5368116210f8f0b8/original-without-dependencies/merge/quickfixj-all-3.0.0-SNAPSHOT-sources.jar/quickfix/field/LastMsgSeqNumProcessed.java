/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class LastMsgSeqNumProcessed extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 369;

  public LastMsgSeqNumProcessed() {
    super(369);
  }

  public LastMsgSeqNumProcessed(Integer data) {
    super(369, data);
  }

  public LastMsgSeqNumProcessed(int data) {
    super(369, data);
  }
}
