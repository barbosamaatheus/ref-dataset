/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class OnBehalfOfLocationID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 144;

  public OnBehalfOfLocationID() {
    super(144);
  }

  public OnBehalfOfLocationID(String data) {
    super(144, data);
  }
}
