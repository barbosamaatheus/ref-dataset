/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class NoHops extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 627;

  public NoHops() {
    super(627);
  }

  public NoHops(Integer data) {
    super(627, data);
  }

  public NoHops(int data) {
    super(627, data);
  }
}
