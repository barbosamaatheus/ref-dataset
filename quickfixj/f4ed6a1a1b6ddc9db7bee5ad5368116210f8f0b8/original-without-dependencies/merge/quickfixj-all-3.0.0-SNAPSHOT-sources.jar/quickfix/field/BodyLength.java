/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class BodyLength extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 9;

  public BodyLength() {
    super(9);
  }

  public BodyLength(Integer data) {
    super(9, data);
  }

  public BodyLength(int data) {
    super(9, data);
  }
}
