/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class SignatureLength extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 93;

  public SignatureLength() {
    super(93);
  }

  public SignatureLength(Integer data) {
    super(93, data);
  }

  public SignatureLength(int data) {
    super(93, data);
  }
}
