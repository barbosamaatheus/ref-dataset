/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class SecureDataLen extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 90;

  public SecureDataLen() {
    super(90);
  }

  public SecureDataLen(Integer data) {
    super(90, data);
  }

  public SecureDataLen(int data) {
    super(90, data);
  }
}
