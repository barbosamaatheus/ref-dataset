/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class DeliverToLocationID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 145;

  public DeliverToLocationID() {
    super(145);
  }

  public DeliverToLocationID(String data) {
    super(145, data);
  }
}
