/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class MessageEncoding extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 347;

  public MessageEncoding() {
    super(347);
  }

  public MessageEncoding(String data) {
    super(347, data);
  }
}
