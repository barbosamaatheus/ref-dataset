/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class NewSeqNo extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 36;

  public NewSeqNo() {
    super(36);
  }

  public NewSeqNo(Integer data) {
    super(36, data);
  }

  public NewSeqNo(int data) {
    super(36, data);
  }
}
