/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class Signature extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 89;

  public Signature() {
    super(89);
  }

  public Signature(String data) {
    super(89, data);
  }
}
