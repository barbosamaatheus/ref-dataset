/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class DeliverToSubID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 129;

  public DeliverToSubID() {
    super(129);
  }

  public DeliverToSubID(String data) {
    super(129, data);
  }
}
