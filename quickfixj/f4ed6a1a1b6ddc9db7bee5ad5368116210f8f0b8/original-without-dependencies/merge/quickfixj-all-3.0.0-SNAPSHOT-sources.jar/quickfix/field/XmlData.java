/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class XmlData extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 213;

  public XmlData() {
    super(213);
  }

  public XmlData(String data) {
    super(213, data);
  }
}
