/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class TargetCompID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 56;

  public TargetCompID() {
    super(56);
  }

  public TargetCompID(String data) {
    super(56, data);
  }
}
