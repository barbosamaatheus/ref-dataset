/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class SenderSubID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 50;

  public SenderSubID() {
    super(50);
  }

  public SenderSubID(String data) {
    super(50, data);
  }
}
