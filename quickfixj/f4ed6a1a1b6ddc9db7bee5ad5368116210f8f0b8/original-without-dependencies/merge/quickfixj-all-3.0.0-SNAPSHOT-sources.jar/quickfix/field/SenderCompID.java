/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class SenderCompID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 49;

  public SenderCompID() {
    super(49);
  }

  public SenderCompID(String data) {
    super(49, data);
  }
}
