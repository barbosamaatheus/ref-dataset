/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class DeliverToCompID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 128;

  public DeliverToCompID() {
    super(128);
  }

  public DeliverToCompID(String data) {
    super(128, data);
  }
}
