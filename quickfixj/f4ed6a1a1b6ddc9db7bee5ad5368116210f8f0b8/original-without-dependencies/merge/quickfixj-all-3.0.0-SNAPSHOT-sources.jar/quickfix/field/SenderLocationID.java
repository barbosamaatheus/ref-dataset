/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class SenderLocationID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 142;

  public SenderLocationID() {
    super(142);
  }

  public SenderLocationID(String data) {
    super(142, data);
  }
}
