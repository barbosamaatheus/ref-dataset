/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class ApplExtID extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 1156;

  public ApplExtID() {
    super(1156);
  }

  public ApplExtID(Integer data) {
    super(1156, data);
  }

  public ApplExtID(int data) {
    super(1156, data);
  }
}
