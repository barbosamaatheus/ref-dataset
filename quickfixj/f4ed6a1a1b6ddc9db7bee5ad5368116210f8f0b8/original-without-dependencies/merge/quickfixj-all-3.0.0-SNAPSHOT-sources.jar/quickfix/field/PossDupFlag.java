/* Generated Java Source File */
package quickfix.field;
import quickfix.BooleanField;

public class PossDupFlag extends BooleanField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 43;

  public static final boolean ORIGINAL_TRANSMISSION = false;

  public static final boolean POSSIBLE_DUPLICATE = true;

  public PossDupFlag() {
    super(43);
  }

  public PossDupFlag(Boolean data) {
    super(43, data);
  }

  public PossDupFlag(boolean data) {
    super(43, data);
  }
}
