/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class BeginString extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 8;

  public BeginString() {
    super(8);
  }

  public BeginString(String data) {
    super(8, data);
  }
}
