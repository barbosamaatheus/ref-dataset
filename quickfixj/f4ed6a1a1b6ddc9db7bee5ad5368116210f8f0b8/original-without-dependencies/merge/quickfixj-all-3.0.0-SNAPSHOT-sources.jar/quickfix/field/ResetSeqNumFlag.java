/* Generated Java Source File */
package quickfix.field;
import quickfix.BooleanField;

public class ResetSeqNumFlag extends BooleanField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 141;

  public static final boolean NO = false;

  public static final boolean YES = true;

  public ResetSeqNumFlag() {
    super(141);
  }

  public ResetSeqNumFlag(Boolean data) {
    super(141, data);
  }

  public ResetSeqNumFlag(boolean data) {
    super(141, data);
  }
}
