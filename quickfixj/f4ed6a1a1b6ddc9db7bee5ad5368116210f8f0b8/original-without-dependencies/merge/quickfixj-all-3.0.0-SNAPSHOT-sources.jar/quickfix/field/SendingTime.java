/* Generated Java Source File */
package quickfix.field;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import quickfix.UtcTimeStampField;

public class SendingTime extends UtcTimeStampField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 52;

  public SendingTime() {
    super(52);
  }

  public SendingTime(LocalDateTime data) {
    super(52, data);
  }
}
