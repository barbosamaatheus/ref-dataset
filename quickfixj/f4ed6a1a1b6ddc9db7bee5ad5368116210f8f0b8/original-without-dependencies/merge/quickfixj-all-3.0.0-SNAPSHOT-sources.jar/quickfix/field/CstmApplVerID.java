/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class CstmApplVerID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 1129;

  public CstmApplVerID() {
    super(1129);
  }

  public CstmApplVerID(String data) {
    super(1129, data);
  }
}
