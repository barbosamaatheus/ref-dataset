/* Generated Java Source File */
package quickfix.field;
import quickfix.BooleanField;

public class GapFillFlag extends BooleanField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 123;

  public static final boolean SEQUENCE_RESET = false;

  public static final boolean GAP_FILL_MESSAGE = true;

  public GapFillFlag() {
    super(123);
  }

  public GapFillFlag(Boolean data) {
    super(123, data);
  }

  public GapFillFlag(boolean data) {
    super(123, data);
  }
}
