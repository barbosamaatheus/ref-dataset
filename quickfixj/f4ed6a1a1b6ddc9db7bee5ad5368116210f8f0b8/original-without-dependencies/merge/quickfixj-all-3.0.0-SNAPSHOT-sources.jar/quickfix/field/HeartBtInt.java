/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class HeartBtInt extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 108;

  public HeartBtInt() {
    super(108);
  }

  public HeartBtInt(Integer data) {
    super(108, data);
  }

  public HeartBtInt(int data) {
    super(108, data);
  }
}
