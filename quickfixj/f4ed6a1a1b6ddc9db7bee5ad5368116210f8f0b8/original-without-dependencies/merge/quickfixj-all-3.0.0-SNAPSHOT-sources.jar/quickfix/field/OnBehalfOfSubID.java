/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class OnBehalfOfSubID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 116;

  public OnBehalfOfSubID() {
    super(116);
  }

  public OnBehalfOfSubID(String data) {
    super(116, data);
  }
}
