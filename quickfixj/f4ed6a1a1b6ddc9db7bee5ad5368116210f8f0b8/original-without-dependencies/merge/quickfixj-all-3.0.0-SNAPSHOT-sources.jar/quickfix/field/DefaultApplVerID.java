/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class DefaultApplVerID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 1137;

  public static final String FIX27 = "0";

  public static final String FIX30 = "1";

  public static final String FIX40 = "2";

  public static final String FIX41 = "3";

  public static final String FIX42 = "4";

  public static final String FIX43 = "5";

  public static final String FIX44 = "6";

  public static final String FIX50 = "7";

  public static final String FIX50SP1 = "8";

  public static final String FIX50SP2 = "9";

  public static final String FIXLATEST = "10";

  public DefaultApplVerID() {
    super(1137);
  }

  public DefaultApplVerID(String data) {
    super(1137, data);
  }
}
