/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class TargetLocationID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 143;

  public TargetLocationID() {
    super(143);
  }

  public TargetLocationID(String data) {
    super(143, data);
  }
}
