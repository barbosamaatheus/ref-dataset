/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class OnBehalfOfCompID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 115;

  public OnBehalfOfCompID() {
    super(115);
  }

  public OnBehalfOfCompID(String data) {
    super(115, data);
  }
}
