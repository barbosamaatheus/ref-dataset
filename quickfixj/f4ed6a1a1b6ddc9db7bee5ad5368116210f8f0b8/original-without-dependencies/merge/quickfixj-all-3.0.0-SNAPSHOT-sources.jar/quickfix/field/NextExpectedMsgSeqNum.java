/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class NextExpectedMsgSeqNum extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 789;

  public NextExpectedMsgSeqNum() {
    super(789);
  }

  public NextExpectedMsgSeqNum(Integer data) {
    super(789, data);
  }

  public NextExpectedMsgSeqNum(int data) {
    super(789, data);
  }
}
