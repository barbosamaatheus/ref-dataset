/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class CheckSum extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 10;

  public CheckSum() {
    super(10);
  }

  public CheckSum(String data) {
    super(10, data);
  }
}
