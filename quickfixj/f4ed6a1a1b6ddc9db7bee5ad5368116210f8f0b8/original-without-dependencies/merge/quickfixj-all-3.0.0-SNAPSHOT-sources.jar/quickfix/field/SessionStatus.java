/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class SessionStatus extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 1409;

  public static final int SESSION_ACTIVE = 0;

  public static final int SESSION_PASSWORD_CHANGED = 1;

  public static final int SESSION_PASSWORD_DUE_TO_EXPIRE = 2;

  public static final int NEW_SESSION_PASSWORD_DOES_NOT_COMPLY_WITH_POLICY = 3;

  public static final int SESSION_LOGOUT_COMPLETE = 4;

  public static final int INVALID_USERNAME_OR_PASSWORD = 5;

  public static final int ACCOUNT_LOCKED = 6;

  public static final int LOGONS_ARE_NOT_ALLOWED_AT_THIS_TIME = 7;

  public static final int PASSWORD_EXPIRED = 8;

  public static final int RECEIVED_MSG_SEQ_NUM_TOO_LOW = 9;

  public static final int RECEIVED_NEXT_EXPECTED_MSG_SEQ_NUM_TOO_HIGH = 10;

  public SessionStatus() {
    super(1409);
  }

  public SessionStatus(Integer data) {
    super(1409, data);
  }

  public SessionStatus(int data) {
    super(1409, data);
  }
}
