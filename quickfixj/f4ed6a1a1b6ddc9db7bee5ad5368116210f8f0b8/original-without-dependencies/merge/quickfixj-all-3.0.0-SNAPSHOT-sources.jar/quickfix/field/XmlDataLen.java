/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class XmlDataLen extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 212;

  public XmlDataLen() {
    super(212);
  }

  public XmlDataLen(Integer data) {
    super(212, data);
  }

  public XmlDataLen(int data) {
    super(212, data);
  }
}
