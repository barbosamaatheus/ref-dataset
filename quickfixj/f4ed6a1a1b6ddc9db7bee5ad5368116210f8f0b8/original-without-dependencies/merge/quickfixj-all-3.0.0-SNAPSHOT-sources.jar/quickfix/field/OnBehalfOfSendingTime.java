/* Generated Java Source File */
package quickfix.field;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import quickfix.UtcTimeStampField;

public class OnBehalfOfSendingTime extends UtcTimeStampField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 370;

  public OnBehalfOfSendingTime() {
    super(370);
  }

  public OnBehalfOfSendingTime(LocalDateTime data) {
    super(370, data);
  }
}
