/* Generated Java Source File */
package quickfix.field;
import quickfix.IntField;

public class BeginSeqNo extends IntField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 7;

  public BeginSeqNo() {
    super(7);
  }

  public BeginSeqNo(Integer data) {
    super(7, data);
  }

  public BeginSeqNo(int data) {
    super(7, data);
  }
}
