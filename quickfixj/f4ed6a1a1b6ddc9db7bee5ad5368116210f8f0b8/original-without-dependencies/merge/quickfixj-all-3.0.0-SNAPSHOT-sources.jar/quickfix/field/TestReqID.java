/* Generated Java Source File */
package quickfix.field;
import quickfix.StringField;

public class TestReqID extends StringField {
  static final long serialVersionUID = 552892318L;

  public static final int FIELD = 112;

  public TestReqID() {
    super(112);
  }

  public TestReqID(String data) {
    super(112, data);
  }
}
