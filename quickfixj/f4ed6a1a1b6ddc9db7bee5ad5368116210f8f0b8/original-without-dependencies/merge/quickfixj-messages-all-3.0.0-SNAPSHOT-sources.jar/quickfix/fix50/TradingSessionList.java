
package quickfix.fix50;

import quickfix.FieldNotFound;

import quickfix.Group;

public class TradingSessionList extends Message {

	static final long serialVersionUID = 20050617;
	public static final String MSGTYPE = "BJ";
	

	public TradingSessionList() {
		super();
		getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
	}
	
	public void set(quickfix.field.TradSesReqID value) {
		setField(value);
	}

	public quickfix.field.TradSesReqID get(quickfix.field.TradSesReqID value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesReqID getTradSesReqID() throws FieldNotFound {
		return get(new quickfix.field.TradSesReqID());
	}

	public boolean isSet(quickfix.field.TradSesReqID field) {
		return isSetField(field);
	}

	public boolean isSetTradSesReqID() {
		return isSetField(335);
	}

	public void set(quickfix.fix50.component.TrdSessLstGrp component) {
		setComponent(component);
	}

	public quickfix.fix50.component.TrdSessLstGrp get(quickfix.fix50.component.TrdSessLstGrp component) throws FieldNotFound {
		getComponent(component);
		return component;
	}

	public quickfix.fix50.component.TrdSessLstGrp getTrdSessLstGrp() throws FieldNotFound {
		return get(new quickfix.fix50.component.TrdSessLstGrp());
	}

	public void set(quickfix.field.NoTradingSessions value) {
		setField(value);
	}

	public quickfix.field.NoTradingSessions get(quickfix.field.NoTradingSessions value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.NoTradingSessions getNoTradingSessions() throws FieldNotFound {
		return get(new quickfix.field.NoTradingSessions());
	}

	public boolean isSet(quickfix.field.NoTradingSessions field) {
		return isSetField(field);
	}

	public boolean isSetNoTradingSessions() {
		return isSetField(386);
	}

	public static class NoTradingSessions extends Group {

		static final long serialVersionUID = 20050617;
		private static final int[] ORDER = {336, 625, 207, 338, 339, 325, 340, 567, 341, 342, 343, 344, 345, 387, 58, 354, 355, 0};

		public NoTradingSessions() {
			super(386, 336, ORDER);
		}
		
	public void set(quickfix.field.TradingSessionID value) {
		setField(value);
	}

	public quickfix.field.TradingSessionID get(quickfix.field.TradingSessionID value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradingSessionID getTradingSessionID() throws FieldNotFound {
		return get(new quickfix.field.TradingSessionID());
	}

	public boolean isSet(quickfix.field.TradingSessionID field) {
		return isSetField(field);
	}

	public boolean isSetTradingSessionID() {
		return isSetField(336);
	}

	public void set(quickfix.field.TradingSessionSubID value) {
		setField(value);
	}

	public quickfix.field.TradingSessionSubID get(quickfix.field.TradingSessionSubID value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradingSessionSubID getTradingSessionSubID() throws FieldNotFound {
		return get(new quickfix.field.TradingSessionSubID());
	}

	public boolean isSet(quickfix.field.TradingSessionSubID field) {
		return isSetField(field);
	}

	public boolean isSetTradingSessionSubID() {
		return isSetField(625);
	}

	public void set(quickfix.field.SecurityExchange value) {
		setField(value);
	}

	public quickfix.field.SecurityExchange get(quickfix.field.SecurityExchange value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.SecurityExchange getSecurityExchange() throws FieldNotFound {
		return get(new quickfix.field.SecurityExchange());
	}

	public boolean isSet(quickfix.field.SecurityExchange field) {
		return isSetField(field);
	}

	public boolean isSetSecurityExchange() {
		return isSetField(207);
	}

	public void set(quickfix.field.TradSesMethod value) {
		setField(value);
	}

	public quickfix.field.TradSesMethod get(quickfix.field.TradSesMethod value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesMethod getTradSesMethod() throws FieldNotFound {
		return get(new quickfix.field.TradSesMethod());
	}

	public boolean isSet(quickfix.field.TradSesMethod field) {
		return isSetField(field);
	}

	public boolean isSetTradSesMethod() {
		return isSetField(338);
	}

	public void set(quickfix.field.TradSesMode value) {
		setField(value);
	}

	public quickfix.field.TradSesMode get(quickfix.field.TradSesMode value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesMode getTradSesMode() throws FieldNotFound {
		return get(new quickfix.field.TradSesMode());
	}

	public boolean isSet(quickfix.field.TradSesMode field) {
		return isSetField(field);
	}

	public boolean isSetTradSesMode() {
		return isSetField(339);
	}

	public void set(quickfix.field.UnsolicitedIndicator value) {
		setField(value);
	}

	public quickfix.field.UnsolicitedIndicator get(quickfix.field.UnsolicitedIndicator value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.UnsolicitedIndicator getUnsolicitedIndicator() throws FieldNotFound {
		return get(new quickfix.field.UnsolicitedIndicator());
	}

	public boolean isSet(quickfix.field.UnsolicitedIndicator field) {
		return isSetField(field);
	}

	public boolean isSetUnsolicitedIndicator() {
		return isSetField(325);
	}

	public void set(quickfix.field.TradSesStatus value) {
		setField(value);
	}

	public quickfix.field.TradSesStatus get(quickfix.field.TradSesStatus value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesStatus getTradSesStatus() throws FieldNotFound {
		return get(new quickfix.field.TradSesStatus());
	}

	public boolean isSet(quickfix.field.TradSesStatus field) {
		return isSetField(field);
	}

	public boolean isSetTradSesStatus() {
		return isSetField(340);
	}

	public void set(quickfix.field.TradSesStatusRejReason value) {
		setField(value);
	}

	public quickfix.field.TradSesStatusRejReason get(quickfix.field.TradSesStatusRejReason value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesStatusRejReason getTradSesStatusRejReason() throws FieldNotFound {
		return get(new quickfix.field.TradSesStatusRejReason());
	}

	public boolean isSet(quickfix.field.TradSesStatusRejReason field) {
		return isSetField(field);
	}

	public boolean isSetTradSesStatusRejReason() {
		return isSetField(567);
	}

	public void set(quickfix.field.TradSesStartTime value) {
		setField(value);
	}

	public quickfix.field.TradSesStartTime get(quickfix.field.TradSesStartTime value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesStartTime getTradSesStartTime() throws FieldNotFound {
		return get(new quickfix.field.TradSesStartTime());
	}

	public boolean isSet(quickfix.field.TradSesStartTime field) {
		return isSetField(field);
	}

	public boolean isSetTradSesStartTime() {
		return isSetField(341);
	}

	public void set(quickfix.field.TradSesOpenTime value) {
		setField(value);
	}

	public quickfix.field.TradSesOpenTime get(quickfix.field.TradSesOpenTime value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesOpenTime getTradSesOpenTime() throws FieldNotFound {
		return get(new quickfix.field.TradSesOpenTime());
	}

	public boolean isSet(quickfix.field.TradSesOpenTime field) {
		return isSetField(field);
	}

	public boolean isSetTradSesOpenTime() {
		return isSetField(342);
	}

	public void set(quickfix.field.TradSesPreCloseTime value) {
		setField(value);
	}

	public quickfix.field.TradSesPreCloseTime get(quickfix.field.TradSesPreCloseTime value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesPreCloseTime getTradSesPreCloseTime() throws FieldNotFound {
		return get(new quickfix.field.TradSesPreCloseTime());
	}

	public boolean isSet(quickfix.field.TradSesPreCloseTime field) {
		return isSetField(field);
	}

	public boolean isSetTradSesPreCloseTime() {
		return isSetField(343);
	}

	public void set(quickfix.field.TradSesCloseTime value) {
		setField(value);
	}

	public quickfix.field.TradSesCloseTime get(quickfix.field.TradSesCloseTime value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesCloseTime getTradSesCloseTime() throws FieldNotFound {
		return get(new quickfix.field.TradSesCloseTime());
	}

	public boolean isSet(quickfix.field.TradSesCloseTime field) {
		return isSetField(field);
	}

	public boolean isSetTradSesCloseTime() {
		return isSetField(344);
	}

	public void set(quickfix.field.TradSesEndTime value) {
		setField(value);
	}

	public quickfix.field.TradSesEndTime get(quickfix.field.TradSesEndTime value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TradSesEndTime getTradSesEndTime() throws FieldNotFound {
		return get(new quickfix.field.TradSesEndTime());
	}

	public boolean isSet(quickfix.field.TradSesEndTime field) {
		return isSetField(field);
	}

	public boolean isSetTradSesEndTime() {
		return isSetField(345);
	}

	public void set(quickfix.field.TotalVolumeTraded value) {
		setField(value);
	}

	public quickfix.field.TotalVolumeTraded get(quickfix.field.TotalVolumeTraded value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.TotalVolumeTraded getTotalVolumeTraded() throws FieldNotFound {
		return get(new quickfix.field.TotalVolumeTraded());
	}

	public boolean isSet(quickfix.field.TotalVolumeTraded field) {
		return isSetField(field);
	}

	public boolean isSetTotalVolumeTraded() {
		return isSetField(387);
	}

	public void set(quickfix.field.Text value) {
		setField(value);
	}

	public quickfix.field.Text get(quickfix.field.Text value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Text getText() throws FieldNotFound {
		return get(new quickfix.field.Text());
	}

	public boolean isSet(quickfix.field.Text field) {
		return isSetField(field);
	}

	public boolean isSetText() {
		return isSetField(58);
	}

	public void set(quickfix.field.EncodedTextLen value) {
		setField(value);
	}

	public quickfix.field.EncodedTextLen get(quickfix.field.EncodedTextLen value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.EncodedTextLen getEncodedTextLen() throws FieldNotFound {
		return get(new quickfix.field.EncodedTextLen());
	}

	public boolean isSet(quickfix.field.EncodedTextLen field) {
		return isSetField(field);
	}

	public boolean isSetEncodedTextLen() {
		return isSetField(354);
	}

	public void set(quickfix.field.EncodedText value) {
		setField(value);
	}

	public quickfix.field.EncodedText get(quickfix.field.EncodedText value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.EncodedText getEncodedText() throws FieldNotFound {
		return get(new quickfix.field.EncodedText());
	}

	public boolean isSet(quickfix.field.EncodedText field) {
		return isSetField(field);
	}

	public boolean isSetEncodedText() {
		return isSetField(355);
	}

	}

}
