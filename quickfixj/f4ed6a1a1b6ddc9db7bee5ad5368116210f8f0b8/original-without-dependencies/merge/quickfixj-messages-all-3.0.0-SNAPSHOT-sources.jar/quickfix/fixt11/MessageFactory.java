/* Generated Java Source File */
package quickfix.fixt11;
import quickfix.Message;
import quickfix.Group;

public class MessageFactory implements quickfix.MessageFactory {

  public Message create(String beginString, String msgType) {
    switch (msgType) {
    case quickfix.fixt11.Heartbeat.MSGTYPE:
      return new quickfix.fixt11.Heartbeat();
    case quickfix.fixt11.TestRequest.MSGTYPE:
      return new quickfix.fixt11.TestRequest();
    case quickfix.fixt11.ResendRequest.MSGTYPE:
      return new quickfix.fixt11.ResendRequest();
    case quickfix.fixt11.Reject.MSGTYPE:
      return new quickfix.fixt11.Reject();
    case quickfix.fixt11.SequenceReset.MSGTYPE:
      return new quickfix.fixt11.SequenceReset();
    case quickfix.fixt11.Logout.MSGTYPE:
      return new quickfix.fixt11.Logout();
    case quickfix.fixt11.Logon.MSGTYPE:
      return new quickfix.fixt11.Logon();
    case quickfix.fixt11.XMLnonFIX.MSGTYPE:
      return new quickfix.fixt11.XMLnonFIX();
    }
    return new quickfix.fixt11.Message();
  }

  public Group create(String beginString, String msgType, int correspondingFieldID) {
    switch (msgType) {
  case quickfix.fixt11.Heartbeat.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.TestRequest.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.ResendRequest.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.Reject.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.SequenceReset.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.Logout.MSGTYPE:
    switch (correspondingFieldID) {
    }
    break;
  case quickfix.fixt11.Logon.MSGTYPE:
    switch (correspondingFieldID) {
      case quickfix.field.NoMsgTypes.FIELD:
        return new quickfix.fixt11.Logon.NoMsgTypes();
    }
    break;
  case quickfix.fixt11.XMLnonFIX.MSGTYPE:
    switch (correspondingFieldID) {
      case quickfix.field.NoAttachments.FIELD:
        return new quickfix.fixt11.XMLnonFIX.NoAttachments();
      case quickfix.field.NoAttachmentKeywords.FIELD:
        return new quickfix.fixt11.XMLnonFIX.NoAttachments.NoAttachmentKeywords();
    }
    break;
    }
    return null;
  }
}
