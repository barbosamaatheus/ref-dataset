/* Generated Java Source File */
package quickfix.fixt11;
import quickfix.field.*;

public class Message extends quickfix.Message {
  static final long serialVersionUID = 552892318L;

  public Message() {
    this(null);
  }
  protected Message(int[] fieldOrder) {
    super(fieldOrder);
    header = new Header(this);
    trailer = new Trailer();
    getHeader().setField(new BeginString("FIXT.1.1"));
  }

public static class Header extends quickfix.Message.Header {
  static final long serialVersionUID = 552892318L;

  public Header(Message msg) {

  }
}
}
