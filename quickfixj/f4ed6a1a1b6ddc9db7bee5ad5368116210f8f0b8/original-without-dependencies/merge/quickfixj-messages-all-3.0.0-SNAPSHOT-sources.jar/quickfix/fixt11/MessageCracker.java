/* Generated Java Source File */
package quickfix.fixt11;
import quickfix.*;
import quickfix.field.*;

public class MessageCracker {

  public void onMessage(quickfix.Message message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for Heartbeat message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(Heartbeat message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for TestRequest message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(TestRequest message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for ResendRequest message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(ResendRequest message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for Reject message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(Reject message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for SequenceReset message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(SequenceReset message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for Logout message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(Logout message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for Logon message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(Logon message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }
  /**
   * Callback for XMLnonFIX message.
   * @param message
   * @param sessionID
   * @throws FieldNotFound
   * @throws UnsupportedMessageType
   * @throws IncorrectTagValue
   */

  public void onMessage(XMLnonFIX message, SessionID sessionID) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue {
    throw new UnsupportedMessageType();
  }

  public void crack(quickfix.Message message, SessionID sessionID)
    throws UnsupportedMessageType, FieldNotFound, IncorrectTagValue {
    crackfixt11((Message) message, sessionID);
  }

  public void crackfixt11(Message message, SessionID sessionID)
    throws UnsupportedMessageType, FieldNotFound, IncorrectTagValue {
    String type = message.getHeader().getString(MsgType.FIELD);
    switch (type) {
    case Heartbeat.MSGTYPE:
      onMessage((Heartbeat)message, sessionID);
      break;
    case TestRequest.MSGTYPE:
      onMessage((TestRequest)message, sessionID);
      break;
    case ResendRequest.MSGTYPE:
      onMessage((ResendRequest)message, sessionID);
      break;
    case Reject.MSGTYPE:
      onMessage((Reject)message, sessionID);
      break;
    case SequenceReset.MSGTYPE:
      onMessage((SequenceReset)message, sessionID);
      break;
    case Logout.MSGTYPE:
      onMessage((Logout)message, sessionID);
      break;
    case Logon.MSGTYPE:
      onMessage((Logon)message, sessionID);
      break;
    case XMLnonFIX.MSGTYPE:
      onMessage((XMLnonFIX)message, sessionID);
      break;
    default:
      onMessage(message, sessionID);
    }
  }
}
